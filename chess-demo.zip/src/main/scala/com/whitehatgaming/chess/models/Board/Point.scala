package com.whitehatgaming.chess.models.Board

case class Point(x: Int, y: Int)

object Point {

}
