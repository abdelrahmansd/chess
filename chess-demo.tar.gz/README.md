### Chess Demo ###

It's a Very Basic Chess .

#### How set up it? ####

###### 1. Extract zip File

###### 2. Compile a Project
```
#!bash
$ cd chess-demo
$ sbt compile
```

#### How run  ####
```
sbt run
```

### Models ###

#### Piece ####
###### DirectionType ######
###### Piece ######
###### Rook ######
###### KNight ######
###### Bishop ######
###### Queen ######
###### King ######
###### Pawn ######

#### Game ####
###### Move ######
###### Player ######

#### Board ####
###### Point ######
###### Tile ######


### Controller ###
###### Board ######
###### Game ######

